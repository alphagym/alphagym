/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
"use strict";
/** @constructor
 * @extends {MedDetalle}
 * @param {HTMLElement} padre elemento que contiene la forma.
 * @param {string} viewId id del elemento que contiene la forma.
 * @param {string} urlMaestra url de la form maestra.
 * @param {CtrlAbc} controlador controlador. */
function MedEntrenador(padre, viewId, urlMaestra, controlador) {
  MedDetalle.call(this, padre, viewId, urlMaestra, controlador);
}
Object.defineProperty(MedEntrenador
,"ENTRENA_NOMBRE", {value: "entrena_nombre"});
MedEntrenador.prototype = Object.create(MedDetalle.prototype);
MedEntrenador.prototype.constructor = MedEntrenador;
/** Despliega el modelo en la forma de detalle. Las fechas llegan como string.
 * @override
 * @param {boolean} nuevo true si el modelo no está registrado en el servidor.
 * @param {Object} viewModel contiene los datos a mostrar. */
MedEntrenador.prototype.muestraViewModel = function (nuevo, viewModel) {
  muestraValue(this.forma,
      MedEntrenador.ENTRENA_NOMBRE, viewModel[MedEntrenador.ENTRENA_NOMBRE]);
};
