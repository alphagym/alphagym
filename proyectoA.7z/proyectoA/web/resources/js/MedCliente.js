/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
"use strict";
/** @constructor
 * @extends {MedDetalle}
 * @param {HTMLElement} padre elemento que contiene la forma.
 * @param {string} viewId id del elemento que contiene la forma.
 * @param {string} urlMaestra url de la form maestra.
 * @param {CtrlAbc} controlador controlador.
 * @param {Object} parametrosGet id del elemento que contiene la forma. */
function MedCliente(padre, viewId, urlMaestra, controlador, parametrosGet) {
  MedDetalle.call(this, padre, viewId, urlMaestra, controlador, parametrosGet);
  Object.defineProperty(this, "adapter_usu_id",
      {value: new AdapterSelect(padre, '#' + MedCliente.USU_ID)});
}
Object.defineProperties(MedCliente, {
  CLI_CORREO: {value: "cli_correo"},
  CLI_NACIMIENTO: {value: "cli_nacimiento"},
  USU_ID: {value: "usu_id"}
});
MedCliente.prototype = Object.create(MedDetalle.prototype);
MedCliente.prototype.constructor = MedCliente;
MedCliente.prototype.iniciaNuevo = function () {
  this.get("-1");
};
/** Despliega el modelo en la forma de detalle. Las fechas llegan como string.
 * @override
 * @param {boolean} nuevo true si el modelo no está registrado en el servidor.
 * @param {Object} viewModel contiene los datos a mostrar. */
MedCliente.prototype.muestraViewModel = function (nuevo, viewModel) {
      muestraValue(this.forma,
      MedCliente.CLI_CORREO, viewModel[MedCliente.CLI_CORREO]);
      muestraValue(this.forma,
      MedCliente.CLI_NACIMIENTO, viewModel[MedCliente.CLI_NACIMIENTO]);
  this.adapter_usu_id.lista = viewModel[MedCliente.USU_ID];
  this.adapter_usu_id.select.disabled = !nuevo;
};
/** Pasa al modelo los datos capturados en la forma de detalle.
 * @override
 * @param {boolean} nuevo true si el modelo no está registrado en el servidor.
 * @param {String} id del viewModel. */
MedCliente.prototype.creaViewModel = function (nuevo, id) {
  var viewModel = MedDetalle.prototype.creaViewModel.call(this, nuevo, id);
  return viewModel;
};

