/* Copyright 2016 Gilberto Pacheco Gallegos Licensed under the Apache License,
 * Version 2.0 (the "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *   http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License. */
package com.gimnasio.comun;

public class ConstantesComun {
  public static final String FORMATO_FECHA = "dd/MM/yyyy";
  public static final String FORMATO_HORA = "HH:mm";
  public static final String FORMATO_FECHA_HORA = FORMATO_FECHA + " "
      + FORMATO_HORA;
  public static final String FORMATO_FECHA_HORA_TZ = FORMATO_FECHA_HORA + " z";
  public static final String ID = "id";
  public static final String TITULO = "titulo";
  public static final String IMAGEN = "imagen";
  public static final String CAMPO1 = "campo1";
  public static final String CAMPO2 = "campo2";
  public static final String LISTADO = "listado";
  public static final String VALOR = "valor";
  public static final String TEXTO = "texto";
  public static final String SELECCIONADA = "seleccionada";
  private ConstantesComun() {
  }
}
