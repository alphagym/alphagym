/* Copyright 2016 Gilberto Pacheco Gallegos Licensed under the Apache License,
 * Version 2.0 (the "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *   http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License. */
package com.gimnasio.comun;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import static com.gimnasio.comun.ConstantesComun.FORMATO_FECHA_HORA;
import static com.gimnasio.comun.ConstantesComun.FORMATO_FECHA_HORA_TZ;
import static com.gimnasio.comun.ConstantesComun.FORMATO_FECHA;
import static com.gimnasio.comun.ConstantesComun.FORMATO_HORA;

public class Dates {
  private Dates() {
  }
  public static Timestamp getTimestamp(Date fecha) {
    return fecha == null ? null : new Timestamp(fecha.getTime());
  }
  public static SimpleDateFormat getFormatoFecha() {
    final SimpleDateFormat dateFormat = new SimpleDateFormat(FORMATO_FECHA,
        Locale.US);
    dateFormat.setTimeZone(getUtc());
    return dateFormat;
  }
  public static SimpleDateFormat getFormatoHora() {
    final SimpleDateFormat dateFormat = new SimpleDateFormat(FORMATO_HORA,
        Locale.US);
    dateFormat.setTimeZone(getUtc());
    return dateFormat;
  }
  public static SimpleDateFormat getFormatoFechaHora(TimeZone timeZone) {
    final SimpleDateFormat dateFormat = new SimpleDateFormat(FORMATO_FECHA_HORA,
        Locale.US);
    dateFormat.setTimeZone(timeZone);
    return dateFormat;
  }
  public static SimpleDateFormat getFormatoWebFechaHoraTimeZone() {
    return new SimpleDateFormat(FORMATO_FECHA_HORA_TZ, Locale.US);
  }
  public static String aDosCaracteres(long cantidad) {
    return cantidad < 10 ? "0" + cantidad : String.valueOf(cantidad);
  }
  public static String getZonaHorariaSimple() {
    final long offset = TimeZone.getDefault().getOffset(new Date().getTime());
    return (offset < 0 ? "-" : "+")
        + aDosCaracteres(Math.abs(offset / (60 * 60 * 1000)))
        + ":" + aDosCaracteres(Math.abs(offset % (60 * 60 * 1000)));
  }
  public static TimeZone getUtc() {
    return TimeZone.getTimeZone("UTC");
  }
  public static Calendar creaCalendarUtc() {
    final Calendar c = Calendar.getInstance(getUtc());
    c.clear();
    return c;
  }
  public static Calendar creaCalendarEnCeros(TimeZone timeZone) {
    final Calendar c = Calendar.getInstance(timeZone);
    c.clear();
    return c;
  }
  @SuppressWarnings("MagicConstant")
  public static Calendar getFechaActualUtc() {
    final Calendar actual = Calendar.getInstance();
    final Calendar fecha = creaCalendarEnCeros(getUtc());
    fecha.set(actual.get(Calendar.YEAR), actual.get(Calendar.MONTH),
        actual.get(Calendar.DAY_OF_MONTH));
    return fecha;
  }
  public static Calendar getHoraActualUtc() {
    final Calendar actual = Calendar.getInstance();
    final Calendar hora = creaCalendarEnCeros(getUtc());
    hora.set(Calendar.HOUR_OF_DAY, actual.get(Calendar.HOUR_OF_DAY));
    hora.set(Calendar.MINUTE, actual.get(Calendar.MINUTE));
    return hora;
  }
}
