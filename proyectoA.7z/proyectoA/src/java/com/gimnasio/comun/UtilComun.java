/* Copyright 2016 Gilberto Pacheco Gallegos Licensed under the Apache License,
 * Version 2.0 (the "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *   http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License. */
package com.gimnasio.comun;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.text.Format;
import java.text.ParseException;
import javax.servlet.ServletException;

public class UtilComun {
  public static String getTexto(InputStream is, String charset) throws
      IOException {
    try (BufferedReader r = new BufferedReader(
        new InputStreamReader(is, charset))) {
      final StringBuilder sb = new StringBuilder();
      for (String line = r.readLine(); line != null; line = r.readLine()) {
        sb.append('\n').append(line);
      }
      return sb.length() == 0 ? "" : sb.substring(1);
    }
  }
  public static void copia(InputStream origen, OutputStream destino) throws
      IOException, ServletException {
    byte buff[] = new byte[1024];
    for (int b = origen.read(buff); b != -1; b = origen.read(buff)) {
      destino.write(buff, 0, b);
    }
  }
  public static String getMensaje(Exception e) {
    final String localizedMessage = e.getLocalizedMessage();
    return localizedMessage == null || localizedMessage.isEmpty() ? e.toString()
        : localizedMessage;
  }
  public static String format(Format format, Object objeto) {
    return objeto == null ? null : format.format(objeto);
  }
  public static Object parse(Format format, String texto,
      String mensajeDeError) throws Exception {
    try {
      return Strings.isNullOrEmpty(texto) ? null : format.parseObject(texto);
    } catch (ParseException e) {
      throw new Exception(mensajeDeError);
    }
  }
}
