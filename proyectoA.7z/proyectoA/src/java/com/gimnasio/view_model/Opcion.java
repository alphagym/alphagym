/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gimnasio.view_model;

import java.util.Objects;

/**
 *
 * @author gil
 */
public class Opcion {
  private boolean seleccionada;
  private String valor;
  private String texto;
  public Opcion() {
  }
  public Opcion(Object valor, Object texto) {
    this.valor = Objects.toString(valor, null);
    this.texto = Objects.toString(texto, null);
  }
  public Opcion(boolean seleccionada, String valor, String texto) {
    this.seleccionada = seleccionada;
    this.valor = valor;
    this.texto = texto;
  }

    public Opcion(Integer id, String entrena_nombre, String apellido_pat, String apellido_mat, String correo) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
  public boolean isSeleccionada() {
    return seleccionada;
  }
  public void setSeleccionada(boolean seleccionada) {
    this.seleccionada = seleccionada;
  }
  public String getValor() {
    return valor;
  }
  public void setValor(String valor) {
    this.valor = valor;
  }
  public String getTexto() {
    return texto;
  }
  public void setTexto(String texto) {
    this.texto = texto;
  }
}
