/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gimnasio.view_model;

import java.util.Objects;

/**
 *
 * @author gil
 */
public class ElementoDeLista {
  private String id;
  private String imagen;
  private String campo1;
  private String campo2;
  public ElementoDeLista() {
  }
  public ElementoDeLista(Object id, Object campo1, Object campo2) {
    this.id = Objects.toString(id, null);
    this.campo1 = Objects.toString(campo1, null);
    this.campo2 = Objects.toString(campo2, null);
  }
  public ElementoDeLista(Object id, String urlBase,
      Object imagen, Object campo1, Object campo2) {
    this.id = Objects.toString(id, null);
    this.imagen = imagen == null ? null : urlBase + imagen;
    this.campo1 = Objects.toString(campo1, null);
    this.campo2 = Objects.toString(campo2, null);
  }

    public ElementoDeLista(Integer id, String entrena_nombre, String apellido_pat, Object object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public ElementoDeLista(Integer id, String entrena_nombre, String apellido_pat, String apellido_mat, String correo, Object object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }
  public String getImagen() {
    return imagen;
  }
  public void setImagen(String imagen) {
    this.imagen = imagen;
  }
  public String getCampo1() {
    return campo1;
  }
  public void setCampo1(String campo1) {
    this.campo1 = campo1;
  }
  public String getCampo2() {
    return campo2;
  }
  public void setCampo2(String campo2) {
    this.campo2 = campo2;
  }
}
