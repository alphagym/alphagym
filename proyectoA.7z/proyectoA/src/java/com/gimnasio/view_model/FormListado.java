/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gimnasio.view_model;

import java.util.List;

/**
 *
 * @author gil
 */
public class FormListado {
  private List<ElementoDeLista> listado;
  public List<ElementoDeLista> getListado() {
    return listado;
  }
  public void setListado(List<ElementoDeLista> listado) {
    this.listado = listado;
  }
}
