/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gimnasio.app.info;

import com.gimnasio.app.entity.Dia;
import com.gimnasio.servlets.InfoBase;
import com.gimnasio.view_model.ElementoDeLista;
import com.gimnasio.view_model.Opcion;
import java.util.List;
import java.util.stream.Collectors;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author usuario
 */
@Stateless
public class InfoDia extends InfoBase<Dia, Integer> {
  @PersistenceContext(unitName = "proyectoAPU")
  private EntityManager em;
  @Override protected EntityManager getEntityManager() {
    return em;
  }
  public InfoDia() {
    super(Dia.class);
  }
  public List<Dia> select() {
    return getEntityManager().createNamedQuery(Dia.TODOS, Dia.class).
        getResultList();
  }
  public List<Dia> selectIds(List<Integer> ids) {
    return getEntityManager().
        createNamedQuery(ids == null ? Dia.TODOS : Dia.BUSCA_IDS,
            Dia.class).setParameter("ids", ids).getResultList();
  }
  public List<ElementoDeLista> selectElementoDeLista() {
    return select().stream().map(
        p -> new ElementoDeLista(p.getId(), p.getDia_nombre(), null)).
        collect(Collectors.toList());
  }
  public List<Opcion> selectOpciones() {
    return select().stream().map(p -> new Opcion(p.getId(), p.getDia_nombre())).
        collect(Collectors.toList());
  }
}
