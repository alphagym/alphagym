/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gimnasio.app.info;

import static com.gimnasio.app.Constantes.URL_ARCHIVO;
import com.gimnasio.app.entity.Clientes;
import com.gimnasio.app.entity.Usuarios;
import com.gimnasio.servlets.InfoBase;
import com.gimnasio.view_model.ElementoDeLista;
import java.util.List;
import java.util.stream.Collectors;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateless
public class InfoClientes extends InfoBase<Clientes, Integer> {
  @PersistenceContext(unitName = "proyectoAPU")
  private EntityManager em;
  @Override protected EntityManager getEntityManager() {
    return em;
  }
  public InfoClientes() {
    super(Clientes.class);
  }
  @Override
  public void insert(Clientes entity) throws Exception {
    entity.setUsuarios(em.find(Usuarios.class, entity.getId()));
    super.insert(entity);
  }
  @Override
  public Clientes update(Clientes entity) throws Exception {
    entity.setUsuarios(em.find(Usuarios.class, entity.getId()));
    return super.update(entity);
  }
  public List<Clientes> select() {
    return getEntityManager().createNamedQuery(Clientes.TODOS, Clientes.class).
        getResultList();
  }
  public List<ElementoDeLista> selectElementosDeLista() {
    return select().stream().map(c
        -> new ElementoDeLista(c.getId(), URL_ARCHIVO, c.getUsuarios().
            getAvatar().getId(), c.getUsuarios().getClave(), c.getUsuarios().getNombre())).
        collect(Collectors.toList());
  }
}

