/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gimnasio.app.info;

import static com.gimnasio.app.Constantes.ARCH_BYTES;
import static com.gimnasio.app.Constantes.NO_ENCONTRADO;
import com.gimnasio.app.entity.Archivo;
import static com.gimnasio.comun.UtilComun.copia;
import com.gimnasio.servlets.InfoBase;
import static com.gimnasio.servlets.UtilServlets.muestraSinCache;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLConnection;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.annotation.Resource;
import javax.ejb.EJBContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author usuario
 */
@Stateless
public class InfoArchivo extends InfoBase<Archivo, Integer> {
  @PersistenceContext(unitName = "proyectoAPU")
  private EntityManager em;
  @Resource
  private EJBContext context;
  @Override
  protected EntityManager getEntityManager() {
    return em;
  }
  public InfoArchivo() {
    super(Archivo.class);
  }
  @Override public void insert(Archivo entity) throws Exception {
    final Connection c = em.unwrap(Connection.class);
    try (PreparedStatement ps = c.prepareStatement(
        "INSERT INTO Archivos(arch_bytes)VALUES(?)",
        Statement.RETURN_GENERATED_KEYS)) {
      ps.setBinaryStream(1, entity.getBytes());
      ps.executeUpdate();
      try (ResultSet rs = ps.getGeneratedKeys()) {
        if (rs.next()) {
          entity.setId(rs.getInt(1));
        }
      }
    } catch (SQLException ex) {
      context.setRollbackOnly();
      throw ex;
    }
  }
  @Override public Archivo update(Archivo entity) throws Exception {
    throw new UnsupportedOperationException("Update no soportado.");
  }
  public void muestraBytes(int id, HttpServletResponse respuesta) throws
      IOException, ServletException, SQLException {
    final Connection c = em.unwrap(Connection.class);
    try (PreparedStatement ps = c.prepareStatement(
        "SELECT arch_bytes FROM Archivos WHERE arch_id = ?")) {
      ps.setInt(1, id);
      try (ResultSet rs = ps.executeQuery()) {
        if (rs.next()) {
          final Blob arch_bytes = rs.getBlob(ARCH_BYTES);
          final InputStream bytes = arch_bytes.getBinaryStream();
          muestraSinCache(respuesta);
          // Obtiene el tipo de los datos del archivo.
          final String contentType = URLConnection.
              guessContentTypeFromStream(bytes);
          respuesta.setContentType(contentType);
          final ServletOutputStream out = respuesta.getOutputStream();
          copia(bytes, out);
        } else {
          throw new SQLException(NO_ENCONTRADO);
        }
      }
    } catch (IOException | ServletException | SQLException ex) {
      context.setRollbackOnly();
      throw ex;
    }
  }
}
