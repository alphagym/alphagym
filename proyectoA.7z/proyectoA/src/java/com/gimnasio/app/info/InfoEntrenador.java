/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gimnasio.app.info;

import com.gimnasio.app.entity.Entrenador;
import com.gimnasio.servlets.InfoBase;
import com.gimnasio.view_model.ElementoDeLista;
import com.gimnasio.view_model.Opcion;
import java.util.List;
import java.util.stream.Collectors;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author jesus_000
 */
@Stateless
public class InfoEntrenador extends InfoBase<Entrenador, Integer> {
  @PersistenceContext(unitName = "proyectoAPU")
  private EntityManager em;
  @Override protected EntityManager getEntityManager() {
    return em;
  }
  public InfoEntrenador() {
    super(Entrenador.class);
  }
  public List<Entrenador> select() {
    return getEntityManager().createNamedQuery(Entrenador.TODOS, Entrenador.class).
        getResultList();
  }
  public List<Entrenador> selectIds(List<Integer> ids) {
    return getEntityManager().
        createNamedQuery(ids == null ? Entrenador.TODOS : Entrenador.BUSCA_IDS,
            Entrenador.class).setParameter("ids", ids).getResultList();
  }
  public List<ElementoDeLista> selectElementoDeLista() {
    return select().stream().map(
        p -> new ElementoDeLista(p.getId(), p.getEntrena_nombre(), null)).
        collect(Collectors.toList());
  }
  public List<Opcion> selectOpciones() {
    return select().stream().map(p -> new Opcion(p.getId(), p.getEntrena_nombre())).
        collect(Collectors.toList());
  }
}
