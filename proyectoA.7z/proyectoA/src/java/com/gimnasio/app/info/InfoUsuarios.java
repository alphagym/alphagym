/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gimnasio.app.info;

import static com.gimnasio.app.Constantes.URL_ARCHIVO;
import com.gimnasio.app.entity.Usuarios;
import com.gimnasio.comun.Strings;
import static com.gimnasio.comun.Strings.isNullOrEmpty;
import com.gimnasio.servlets.InfoBase;
import static com.gimnasio.servlets.UtilServlets.encripta;
import com.gimnasio.view_model.ElementoDeLista;
import com.gimnasio.view_model.Opcion;
import java.util.List;
import java.util.stream.Collectors;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;

/**
 *
 * @author usuario
 */
@Stateless
public class InfoUsuarios extends InfoBase<Usuarios, Integer> {
  @PersistenceContext(unitName = "proyectoAPU")
  private EntityManager em;
  @EJB InfoArchivo infoArchivo;
  @Override protected EntityManager getEntityManager() {
    return em;
  }
  public InfoUsuarios() {
    super(Usuarios.class);
  }
  public Usuarios busca(String clave) {
    try {
      return getEntityManager().
          createNamedQuery(Usuarios.BUSCA_CLAVE, Usuarios.class).
          setParameter("clave", clave).getSingleResult();
    } catch (NoResultException e) {
      return null;
    }
  }
  public List<Usuarios> select() {
    return getEntityManager().createNamedQuery(Usuarios.TODOS, Usuarios.class).
        getResultList();
  }
  public List<ElementoDeLista> selectElementosDeLista() {
    return select().stream().map(u -> new ElementoDeLista(u.getId(),
        URL_ARCHIVO, u.getAvatar().getId(), u.getClave(), u.getNombre())).
        collect(Collectors.toList());
  }
  public List<Opcion> selectOpciones() {
    return select().stream().map(
        u -> new Opcion(u.getId(), u.getClave())).collect(Collectors.toList());
  }
  @Override public void insert(Usuarios entity) throws Exception {
    if (Strings.isNullOrEmpty(entity.getContra())) {
      throw new Exception("Falta la contraseña.");
    }
    if (entity.getAvatar() == null) {
      throw new Exception("Falta la imagen.");
    }
    entity.setContra(encripta(entity.getContra()));
    infoArchivo.insert(entity.getAvatar());
    super.insert(entity);
  }
  @Override public Usuarios update(Usuarios entity) throws Exception {
    final Usuarios anterior = get(entity.getId());
    final String usuContra = entity.getContra();
    final String usuContraEncriptada = isNullOrEmpty(usuContra)
        ? anterior.getContra() : encripta(entity.getContra());
    entity.setContra(usuContraEncriptada);
    if (entity.getAvatar() == null) {
      entity.setAvatar(anterior.getAvatar());
    } else {
      infoArchivo.insert(entity.getAvatar());
    }
    return super.update(entity);
  }
}
