/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gimnasio.app.info;

import com.gimnasio.app.entity.Actividad;
import com.gimnasio.servlets.InfoBase;
import com.gimnasio.view_model.ElementoDeLista;
import java.util.List;
import java.util.stream.Collectors;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateless
public class InfoActividad extends InfoBase<Actividad, Integer> {
  @PersistenceContext(unitName = "proyectoAPU")
  private EntityManager em;
  @Override protected EntityManager getEntityManager() {
    return em;
  }
  public InfoActividad() {
    super(Actividad.class);
  }
  public List<Actividad> select() {
    return getEntityManager().createNamedQuery(Actividad.TODOS, Actividad.class).
        getResultList();
  }
  public List<ElementoDeLista> selectElementosDeLista() {
    return select().stream().map(c -> new ElementoDeLista(c.getId(),c.getActividad_nombre(), null)).
        collect(Collectors.toList());
  }
}
