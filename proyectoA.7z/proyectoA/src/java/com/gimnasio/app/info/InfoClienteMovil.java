/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gimnasio.app.info;

import com.gimnasio.app.entity.ClienteMovil;
import com.gimnasio.servlets.InfoBase;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author usuario
 */
@Stateless
public class InfoClienteMovil extends InfoBase<ClienteMovil, String> {
  @PersistenceContext(unitName = "proyectoAPU")
  private EntityManager em;
  @Override
  protected EntityManager getEntityManager() {
    return em;
  }
  public InfoClienteMovil() {
    super(ClienteMovil.class);
  }
  public List<ClienteMovil> select() {
    return getEntityManager().
        createNamedQuery(ClienteMovil.TODOS, ClienteMovil.class).getResultList();
  }
}
