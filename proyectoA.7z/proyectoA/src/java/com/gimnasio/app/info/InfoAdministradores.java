/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gimnasio.app.info;

import com.gimnasio.app.entity.Administradores;
import com.gimnasio.servlets.InfoBase;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author usuario
 */
@Stateless
public class InfoAdministradores extends InfoBase<Administradores, Integer> {
  @PersistenceContext(unitName = "proyectoAPU")
  private EntityManager em;
  @Override protected EntityManager getEntityManager() {
    return em;
  }
  public InfoAdministradores() {
    super(Administradores.class);
  }
}

