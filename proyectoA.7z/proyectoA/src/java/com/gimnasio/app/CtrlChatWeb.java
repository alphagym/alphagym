/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gimnasio.app;

import com.gimnasio.app.info.InfoClienteMovil;
import static com.gimnasio.comun.UtilComun.getTexto;
import com.gimnasio.servlets.UtilServlets;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.SQLException;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.ejb.Singleton;
import javax.json.Json;
import javax.json.JsonArrayBuilder;
import javax.json.JsonBuilderFactory;
import javax.json.JsonObjectBuilder;
import javax.naming.NamingException;
import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

/**
 *
 * @author usuario
 */
@Singleton @ServerEndpoint("/ctrlChatWeb")
public class CtrlChatWeb {
  @EJB private InfoClienteMovil infoClienteMovil;
  private static final Logger LOGGER = Logger.getLogger(CtrlChatWeb.class.
      getName());
  /* Cola para todas las sesiones de WebSocket abiertas. */
  private final Queue<Session> queue = new ConcurrentLinkedQueue<>();
  @OnOpen public void openConnection(Session session) {
    /* Registra la conexión en la cola. */
    queue.add(session);
    LOGGER.log(Level.INFO, "Connection opened.");
  }
  @OnClose public void closedConnection(Session session) {
    /* Saca la sesión de la cola. */
    queue.remove(session);
    LOGGER.log(Level.INFO, "Connection closed.");
  }
  @OnError public void error(Session session, Throwable t) {
    /* Saca la sesión de la cola. */
    queue.remove(session);
    LOGGER.log(Level.INFO, t.toString());
    LOGGER.log(Level.INFO, "Connection error.");
  }
  @OnMessage public void onMessage(Session session, String message) {
    try {
      envia(message);
    } catch (IOException | SQLException | NamingException e) {
      LOGGER.log(Level.SEVERE, "Recibiendo mensaje.", e);
    }
  }
  public void envia(String texto) throws IOException, SQLException,
      NamingException {
    for (Session sess : queue) {
      if (sess.isOpen()) {
        sess.getBasicRemote().sendText(texto);
      }
    }
    notificaMóviles(texto);
  }
  public void notificaMóviles(String texto) throws SQLException,
      IOException, NamingException {
    HttpURLConnection connection = null;
    try {
      final JsonBuilderFactory factory = Json.createBuilderFactory(null);
      final JsonObjectBuilder mensaje = factory.createObjectBuilder();
      final JsonArrayBuilder arr = factory.createArrayBuilder();
      infoClienteMovil.select().stream().forEach(c -> arr.add(c.getId()));
      mensaje.add("registration_ids", arr);
      mensaje.add("data", factory.createObjectBuilder().add("mensaje", texto));
      connection = (HttpURLConnection) new URL(
          "https://fcm.googleapis.com/fcm/send").openConnection();
      connection.setUseCaches(false);
      connection.setDoOutput(true);
      connection.setChunkedStreamingMode(1024);
      connection.setRequestMethod("POST");
      connection.setRequestProperty("Authorization",
          "key=AIzaSyDCkyYi-F8O-4oKD5tmosGGRXX_ChHJ4Ws");
      connection.setRequestProperty("Content-Type", "application/json");
      final OutputStream os = connection.getOutputStream();
      try (PrintWriter printWriter = new PrintWriter(
          new OutputStreamWriter(os, UtilServlets.UTF_8), true)) {
        printWriter.print(mensaje.build());
      }
      final int status = connection.getResponseCode();
      if (200 <= status && status < 300) {
        LOGGER.log(Level.INFO, leeInputStream(connection));
      } else if (status == 500) {
        final String error = leeInputStream(connection);
        throw new IOException(error);
      } else {
        throw new IOException(connection.getResponseMessage());
      }
    } finally {
      if (connection != null) {
        connection.disconnect();
      }
    }
  }
  private static String leeInputStream(HttpURLConnection c) throws IOException {
    try {
      return getTexto(c.getInputStream(), UtilServlets.UTF_8);
    } catch (IOException e) {
      throw new IOException(getTexto(c.getErrorStream(), UtilServlets.UTF_8));
    }
  }
}
