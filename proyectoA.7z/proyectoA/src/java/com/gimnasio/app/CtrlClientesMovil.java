/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gimnasio.app;

import com.gimnasio.app.entity.ClienteMovil;
import com.gimnasio.app.info.InfoClienteMovil;
import com.gimnasio.comun.Lee;
import com.gimnasio.comun.LeeString;
import com.gimnasio.servlets.ServletAbc;
import static com.gimnasio.servlets.UtilServlets.getTexto;
import javax.ejb.EJB;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;

/**
 *
 * @author usuario
 */

@MultipartConfig
@WebServlet(name = "CtrlClientesMovil",
    urlPatterns = {"/ctrlClientesMovil/*", "/faces/ctrlClientesMovil/*"})
public class CtrlClientesMovil extends ServletAbc<ClienteMovil, String> {
  @EJB InfoClienteMovil infoClienteMovil;
  @Override protected Lee<String> getLeeId() {
    return new LeeString();
  }
  @Override protected InfoClienteMovil getInfo() {
    return infoClienteMovil;
  }
  @Override public String getServletInfo() {
    return "Administra los id de Firebase Cloud Messaging.";
  }
  @Override protected void update(String id, ClienteMovil modelo) throws
      Exception {
    throw new UnsupportedOperationException("Update no permitido.");
  }
  @Override protected ClienteMovil leeModelo(HttpServletRequest solicitud)
      throws Exception {
    final ClienteMovil modelo = new ClienteMovil();
    modelo.setId(getTexto(solicitud, "id_cm"));
    return modelo;
  }
}

