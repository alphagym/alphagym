/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gimnasio.app;

import static com.gimnasio.app.Constantes.ADMINISTRADOR;
import static com.gimnasio.app.Constantes.CLIENTE;
import static com.gimnasio.app.Constantes.URL_ARCHIVO;
import com.gimnasio.app.entity.UrlDeInicio;
import com.gimnasio.app.entity.Usuarios;
import com.gimnasio.app.info.InfoUsuarios;
import com.gimnasio.app.view_model.FormSesion;
import static com.gimnasio.servlets.UtilServlets.getTexto;
import static com.gimnasio.servlets.UtilServlets.muestraError;
import static com.gimnasio.servlets.UtilServlets.muestraObjeto;
import java.io.IOException;
import java.io.PrintWriter;
import java.security.Principal;
import java.util.HashSet;
import java.util.Set;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author usuario
 */
@MultipartConfig
@WebServlet(name = "CtrlSesion", urlPatterns = {"/ctrlSesion/*", "/ctrlSes/*",
  "/faces/ctrlSesion/*"})
public class CtrlSesion extends HttpServlet {
  private static final String[] ROLES = {ADMINISTRADOR, CLIENTE};
  @EJB InfoUsuarios infoUsuarios;
  @Override public String getServletInfo() {
    return "Controla la sesión sesión";
  }
  @Override protected void doGet(HttpServletRequest solicitud,
      HttpServletResponse respuesta) throws ServletException, IOException {
    try {
      final FormSesion sesión = new FormSesion();
      final Principal userPrincipal = solicitud.getUserPrincipal();
      if (userPrincipal != null) {
        final String clave = userPrincipal.getName();
        sesión.setUsu_clave(clave);
        final Set<String> roles = new HashSet<>();
        for (String rol : ROLES) {
          if (solicitud.isUserInRole(rol)) {
            roles.add(rol);
          }
        }
        sesión.setRoles(roles);
        final Usuarios usuario = infoUsuarios.busca(clave);
        if (usuario != null) {
          sesión.setUsu_nombre(usuario.getNombre());
          sesión.setUsu_avatar(URL_ARCHIVO + usuario.getAvatar().getId());
        }
      }
      muestraObjeto(respuesta, sesión);
    } catch (Exception e) {
      muestraError(respuesta, getClass().getName(), e);
    }
  }
  @Override
  protected void doPost(HttpServletRequest solicitud,
      HttpServletResponse respuesta) throws ServletException, IOException {
    try {
      final String clave = getTexto(solicitud, "clave");
      final String contraseña = getTexto(solicitud, "contrasena");
      solicitud.login(clave, contraseña);
      doGet(solicitud, respuesta);
    } catch (IOException | ServletException e) {
      muestraError(respuesta, getClass().getName(), e);
    }
  }
  @Override protected void doDelete(HttpServletRequest solicitud,
      HttpServletResponse respuesta) throws ServletException, IOException {
    solicitud.getSession().invalidate();
    final UrlDeInicio urlDeInicio = new UrlDeInicio();
    urlDeInicio.setUrl(solicitud.getServletPath().contains("faces")
        ? "index.xhtml" : "faces/index.xhtml");
    muestraObjeto(respuesta, urlDeInicio);
  }
}
