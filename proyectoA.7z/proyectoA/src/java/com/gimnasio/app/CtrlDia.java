/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gimnasio.app;

import static com.gimnasio.app.Constantes.DIA_NOMBRE;
import static com.gimnasio.app.Constantes.NO_ENCONTRADO;
import com.gimnasio.app.entity.Dia;
import com.gimnasio.app.info.InfoDia;
import com.gimnasio.app.view_model.FormDia;
import com.gimnasio.comun.Lee;
import com.gimnasio.comun.LeeInteger;
import com.gimnasio.servlets.ServletAbc;
import static com.gimnasio.servlets.UtilServlets.getTexto;
import com.gimnasio.view_model.FormListado;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author usuario
 */
@MultipartConfig
@WebServlet(name = "CtrlDia",
    urlPatterns = {"/ctrlDia/*", "/faces/ctrlDia/*"})
public class CtrlDia extends ServletAbc<Dia, Integer> {
  @EJB private InfoDia infoDia;
  @Override public String getServletInfo() {
    return "Administra el catálogo de días.";
  }
  @Override protected InfoDia getInfo() {
    return infoDia;
  }
  @Override protected Lee<Integer> getLeeId() {
    return new LeeInteger();
  }
  @Override protected FormListado list(Map<String, String[]> parámetros) {
    final FormListado forma = new FormListado();
    forma.setListado(infoDia.selectElementoDeLista());
    return forma;
  }
  @Override protected FormDia get(Integer id,
      Map<String, String[]> parámetros) throws Exception {
    final Dia modelo = infoDia.get(id);
    final FormDia forma = new FormDia();
    if (modelo == null) {
      throw new Exception(NO_ENCONTRADO);
    } else {
      forma.setTitulo(modelo.getDia_nombre());
      forma.setDia_nombre(modelo.getDia_nombre());
    }
    return forma;
  }
  @Override protected Dia leeModelo(HttpServletRequest solicitud)
      throws Exception {
    final Dia modelo = new Dia();
    modelo.setDia_nombre(getTexto(solicitud, DIA_NOMBRE));
    return modelo;
  }
}
