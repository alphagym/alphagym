/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gimnasio.app;

import com.gimnasio.app.entity.Administradores;
import com.gimnasio.app.entity.Archivo;
import com.gimnasio.app.entity.Usuarios;
import com.gimnasio.app.info.InfoAdministradores;
import com.gimnasio.app.info.InfoUsuarios;
import java.io.BufferedInputStream;
import java.io.InputStream;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

/**
 *
 * @author usuario
 */
public class ListenerDeApp implements ServletContextListener {
  private final InfoAdministradores infoAdministradores
      = lookupInfoAdministradorBean();
  private final InfoUsuarios infoUsuarios = lookupInfoUsuarioBean();
  @Override public void contextInitialized(ServletContextEvent sce) {
    try {
      if (infoUsuarios.busca("admin") == null) {
        final InputStream is = sce.getServletContext().
            getResourceAsStream("/resources/img/user-icon.png");
        final BufferedInputStream bis = new BufferedInputStream(is);
        final Archivo archivo = new Archivo();
        archivo.setBytes(bis);
        final Usuarios usuarios = new Usuarios();
        usuarios.setAvatar(archivo);
        usuarios.setClave("admin");
        usuarios.setContra("hola");
        usuarios.setNombre("Cámbiame");
        infoUsuarios.insert(usuarios);
        Administradores adm = new Administradores();
        adm.setId(usuarios.getId());
        infoAdministradores.insert(adm);
      }
    } catch (Exception ex) {
      Logger.getLogger(ListenerDeApp.class.getName()).
          log(Level.SEVERE, null, ex);
    }
  }
  @Override public void contextDestroyed(ServletContextEvent sce) {
  }
  private InfoUsuarios lookupInfoUsuarioBean() {
    try {
      Context c = new InitialContext();
      return (InfoUsuarios) c.lookup(
          "java:global/proyectoAapp/InfoUsuarios!com.gimnasio.app.info.InfoUsuarios");
    } catch (NamingException ne) {
      Logger.getLogger(getClass().getName()).
          log(Level.SEVERE, "exception caught", ne);
      throw new RuntimeException(ne);
    }
  }
  private InfoAdministradores lookupInfoAdministradorBean() {
    try {
      Context c = new InitialContext();
      return (InfoAdministradores) c.lookup(
          "java:global/proyectoAapp/InfoAdministradores!com.gimnasio.app.info.InfoAdministradores");
    } catch (NamingException ne) {
      Logger.getLogger(getClass().getName()).
          log(Level.SEVERE, "exception caught", ne);
      throw new RuntimeException(ne);
    }
  }
}

