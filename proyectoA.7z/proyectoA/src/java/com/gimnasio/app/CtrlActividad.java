/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gimnasio.app;

import static com.gimnasio.app.Constantes.ACTIVIDAD_DESC;
import static com.gimnasio.app.Constantes.ACTIVIDAD_NOMBRE;
import static com.gimnasio.app.Constantes.ACTIVIDAD_NUEVA;
import static com.gimnasio.app.Constantes.ID_DIA;
import static com.gimnasio.app.Constantes.NO_ENCONTRADO;
import static com.gimnasio.app.Constantes.SELECCIONA_DIA;
import static com.gimnasio.app.Constantes.SIN_DIA;
import com.gimnasio.app.entity.Actividad;
import com.gimnasio.app.info.InfoActividad;
import com.gimnasio.app.info.InfoDia;
import com.gimnasio.app.view_model.FormActividad;
import com.gimnasio.comun.Lee;
import com.gimnasio.comun.LeeInteger;
import com.gimnasio.servlets.ServletAbc;
import com.gimnasio.servlets.UtilServlets;
import static com.gimnasio.servlets.UtilServlets.configuraSeleccionaUno;
import static com.gimnasio.servlets.UtilServlets.getTexto;
import com.gimnasio.view_model.FormListado;
import java.util.Map;
import javax.ejb.EJB;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;

@MultipartConfig
@WebServlet(name = "CtrlActividad",
    urlPatterns = {"/ctrlActividad/*", "/faces/ctrlActividad/*"})
public class CtrlActividad extends ServletAbc<Actividad, Integer> {
  @EJB private InfoActividad infoActividad;
  @EJB private InfoDia infoDia;
  @Override public String getServletInfo() {
    return "Administra el catálogo de las actividades.";
  }
  @Override protected Lee<Integer> getLeeId() {
    return new LeeInteger();
  }
  @Override protected InfoActividad getInfo() {
    return infoActividad;
  }
  @Override protected FormListado list(Map<String, String[]> parámetros) {
    final FormListado forma = new FormListado();
    forma.setListado(infoActividad.selectElementosDeLista());
    return forma;
  }
  @Override protected FormActividad get(Integer id,
      Map<String, String[]> parámetros) throws Exception {
    final FormActividad forma = new FormActividad();
    final boolean nuevo = id < 0;
    if (nuevo) {
      forma.setTitulo(ACTIVIDAD_NUEVA);
      forma.setId_dia(configuraSeleccionaUno("", SELECCIONA_DIA, "",
          infoDia.selectOpciones()));
    } else {
      final Actividad modelo = infoActividad.get(id);
      if (modelo == null) {
        throw new Exception(NO_ENCONTRADO);
      } else {
       
        forma.setTitulo(modelo.getDia().getDia_nombre());
        forma.setId_dia(configuraSeleccionaUno("", SIN_DIA , id.toString(),
            infoDia.selectOpciones()));
        forma.setActividad_nombre(modelo.getActividad_nombre());
        forma.setActividad_desc(modelo.getActividad_desc());
      }
    }
    return forma;
  }
  @Override protected Actividad leeModelo(HttpServletRequest solicitud) throws
      Exception {
    
    final Actividad modelo = new Actividad();
    
    modelo.setActividad_nombre(getTexto(solicitud, ACTIVIDAD_NOMBRE));
    modelo.setActividad_desc(getTexto(solicitud, ACTIVIDAD_DESC));
    modelo.setDia(infoDia.get(UtilServlets.getInteger(solicitud, ID_DIA)));
    return modelo;
  }
}
