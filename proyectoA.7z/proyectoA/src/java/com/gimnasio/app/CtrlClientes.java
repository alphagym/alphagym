/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gimnasio.app;

import static com.gimnasio.app.Constantes.CLIENTE_NUEVO;
import static com.gimnasio.app.Constantes.CLI_CORREO;
import static com.gimnasio.app.Constantes.CLI_NACIMIENTO;
import static com.gimnasio.app.Constantes.FORMATO_INCORRECTO_PARA_NACIMIENTO;
import static com.gimnasio.app.Constantes.NO_ENCONTRADO;
import static com.gimnasio.app.Constantes.SIN_USUARIO;
import static com.gimnasio.app.Constantes.USU_ID;
import com.gimnasio.app.entity.Clientes;
import com.gimnasio.app.info.InfoClientes;
import com.gimnasio.app.info.InfoUsuarios;
import com.gimnasio.app.view_model.FormClientes;
import com.gimnasio.comun.Dates;
import com.gimnasio.comun.Lee;
import com.gimnasio.comun.LeeInteger;
import static com.gimnasio.comun.UtilComun.format;
import com.gimnasio.servlets.ServletAbc;
import static com.gimnasio.servlets.UtilServlets.configuraSeleccionaUno;
import static com.gimnasio.servlets.UtilServlets.getFecha;
import static com.gimnasio.servlets.UtilServlets.getInteger;
import static com.gimnasio.servlets.UtilServlets.getTexto;
import com.gimnasio.view_model.FormListado;
import java.text.DateFormat;
import java.util.Map;
import javax.ejb.EJB;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;

@MultipartConfig
@WebServlet(name = "CtrlClientes",
    urlPatterns = {"/ctrlClientes/*", "/faces/ctrlClientes/*"})
public class CtrlClientes extends ServletAbc<Clientes, Integer> {
  @EJB private InfoClientes infoClientes;
  @EJB private InfoUsuarios infoUsuarios;
  @Override public String getServletInfo() {
    return "Administra el catálogo de clientes.";
  }
  @Override protected Lee<Integer> getLeeId() {
    return new LeeInteger();
  }
  @Override protected InfoClientes getInfo() {
    return infoClientes;
  }
  @Override protected FormListado list(Map<String, String[]> parámetros) {
    final FormListado forma = new FormListado();
    forma.setListado(infoClientes.selectElementosDeLista());
    return forma;
  }
  @Override protected FormClientes get(Integer id,
      Map<String, String[]> parámetros) throws Exception {
    final FormClientes forma = new FormClientes();
    final boolean nuevo = id < 0;
    if (nuevo) {
      forma.setTitulo(CLIENTE_NUEVO);
      forma.setUsu_id(configuraSeleccionaUno("", SIN_USUARIO, "",
          infoUsuarios.selectOpciones()));
    } else {
      final Clientes modelo = infoClientes.get(id);
      if (modelo == null) {
        throw new Exception(NO_ENCONTRADO);
      } else {
        final DateFormat fmtFecha = Dates.getFormatoFecha();
        
        forma.setTitulo(modelo.getUsuarios().getClave());
        forma.setUsu_id(configuraSeleccionaUno("", SIN_USUARIO, id.toString(),
        infoUsuarios.selectOpciones()));
        forma.setCli_nacimiento(format(fmtFecha, modelo.getNacimiento()));
        forma.setCli_correo(modelo.getCli_correo());
        
        
      }
    }
    return forma;
  }
  @Override protected Clientes leeModelo(HttpServletRequest solicitud) throws
      Exception {
    final DateFormat fmtFecha = Dates.getFormatoFecha();
    final Clientes modelo = new Clientes();
    modelo.setId(getInteger(solicitud, USU_ID));
    modelo.setNacimiento(getFecha(solicitud, CLI_NACIMIENTO, fmtFecha,
    FORMATO_INCORRECTO_PARA_NACIMIENTO));
    modelo.setCli_correo (getTexto(solicitud, CLI_CORREO));
    return modelo;
  }
}

