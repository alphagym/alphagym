/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gimnasio.app;

/**
 *
 * @author usuario
 */
public class Constantes {
  public static final String DIA_NOMBRE= "dia_nombre";
  public static final String ENTRENA_NOMBRE= "entrena_nombre";
  public static final String APELLIDO_PAT= "apellido_pat";
  public static final String APELLIDO_MAT= "apellido_mat";
  public static final String CORREO= "correo";
  public static final String ACTIVIDAD_DIA= "actividad_id"; 
  public static final String ACTIVIDAD_NOMBRE= "actividad_nombre";  
  public static final String ACTIVIDAD_DESC= "actividad_desc";
  public static final String PRECIO= "precio";
  public static final String HORARIO= "horario";
  public static final String ID_DIA= "id_dia";
  public static final String URL_ARCHIVO = "ctrlArchivo/";
  public static final String ADMINISTRADOR = "Administradores";
  public static final String CLIENTE = "Clientes";
  public static final String ID = "id";
  public static final String ARCH_BYTES = "arch_bytes";
  public static final String CLI_NACIMIENTO = "cli_nacimiento";
  public static final String CLI_CORREO = "cli_correo";
  public static final String DET_VNT_CANTIDAD = "det_vnt_cantidad";
  public static final String DET_VNT_PRECIO = "det_vnt_precio";
  public static final String PRD_ID = "prd_id";
  public static final String PRD_NOMBRE = "prd_nombre";
  public static final String PRD_EXISTENCIAS = "prd_existencias";
  public static final String PROV_ID = "prov_id";
  public static final String PROV_IDS = "prov_ids";
  public static final String PROV_NOMBRE = "prov_nombre";
  public static final String USU_AVATAR = "usu_avatar";
  public static final String USU_ID = "usu_id";
  public static final String USU_CLAVE = "usu_clave";
  public static final String USU_CONTRA = "usu_contra";
  public static final String USU_CONTRA2 = "usu_contra2";
  public static final String USU_NOMBRE = "usu_nombre";
  public static final String VNT_FOLIO = "vnt_folio";
  public static final String VNT_ELABORACION = "vnt_elaboracion";
  public static final String ROL_ID = "rol_id";
  public static final String ROLES = "roles";
  public static final String DETALLES = "detalles";
  public static final String FECHA = "fecha";
  public static final String TIME_ZONE = "timeZone";
  public static final String TOTAL = "total";
  public static final String CLIENTE_NUEVO = "Cliente Nuevo";
  public static final String ACTIVIDAD_NUEVA = "Actividad Nueva";
  public static final String PRODUCTO_NUEVO = "Producto Nuevo";
  public static final String AGREGAR_PRODUCTO = "Agregar Producto";
  public static final String FORMATO_DETALLE_DE_VENTA
      = "{0,number,#,##0.00} a ${1,number,#,##0.00} = ${2,number,#,##0.00}";
  public static final String FORMATO_TOTAL = "Total (MN): {0,number,#,##0.00}";
  public static final String FORMATO_MONEDA = "$#,##0.00";
  public static final String FORMATO_CANTIDAD = "#,##0.00";
  public static final String SIN_USUARIO = "-- Sin Usuario --";
   public static final String SIN_DIA = "-- Sin Dia --";
   public static final String SELECCIONA_DIA
      = "-- Selecciona un Dia --";
  public static final String SELECCIONA_PRODUCTO
      = "-- Selecciona un Producto --";
  public static final String NO_ENCONTRADO = "No encontrado.";
  public static final String FORMATO_INCORRECTO_PARA_NACIMIENTO
      = "Formato incorrecto para Nacimiento.";
  public static final String FORMATO_INCORRECTO_PARA_PROXIMA_CITA
      = "Formato incorrecto para Próxima Cita.";
  public static final String FORMATO_INCORRECTO_PARA_HORARIO
      = "Formato incorrecto para Hora Favorita.";
   public static final String FORMATO_INCORRECTO_PARA_HORA_FAVORITA
      = "Formato incorrecto para Hora Favorita.";
  public static final String FORMATO_INCORRECTO_PARA_CANTIDAD
      = "Formato incorrecto para Cantidad.";
  public static final String FORMATO_INCORRECTO_PARA_PRECIO
      = "Formato incorrecto para Precio.";
  public static final String FORMATO_INCORRECTO_PARA_EXISTENCIAS
      = "Formato incorrecto para Existencias.";
  public static final String FALTA_LA_IMAGEN = "Falta la imagen.";
  public static final String LAS_CONTRASENAS_NO_COINCIDEN
      = "Las contraseñas no coinciden.";
  private Constantes() {
  }
}
