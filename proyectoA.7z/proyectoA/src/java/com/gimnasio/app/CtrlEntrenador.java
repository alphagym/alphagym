package com.gimnasio.app;

import static com.gimnasio.app.Constantes.ENTRENA_NOMBRE;
import static com.gimnasio.app.Constantes.NO_ENCONTRADO;
import com.gimnasio.app.entity.Entrenador;
import com.gimnasio.app.info.InfoEntrenador;
import com.gimnasio.app.view_model.FormEntrenador;
import com.gimnasio.comun.Lee;
import com.gimnasio.comun.LeeInteger;
import com.gimnasio.servlets.ServletAbc;
import static com.gimnasio.servlets.UtilServlets.getTexto;
import com.gimnasio.view_model.FormListado;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author jesus_000
 */
@MultipartConfig
@WebServlet(name = "CtrlEntrenador",
    urlPatterns = {"/ctrlEntrenador/*", "/faces/ctrlEntrenador/*"})
public class CtrlEntrenador extends ServletAbc<Entrenador, Integer> {
  @EJB private InfoEntrenador infoEntrenador;
  @Override public String getServletInfo() {
    return "Administra el catálogo de proveedores.";
  }
  @Override protected InfoEntrenador getInfo() {
    return infoEntrenador;
  }
  @Override protected Lee<Integer> getLeeId() {
    return new LeeInteger();
  }
  @Override protected FormListado list(Map<String, String[]> parámetros) {
    final FormListado forma = new FormListado();
    forma.setListado(infoEntrenador.selectElementoDeLista());
    return forma;
  }
  @Override protected FormEntrenador get(Integer id,
      Map<String, String[]> parámetros) throws Exception {
    final Entrenador modelo = infoEntrenador.get(id);
    final FormEntrenador forma = new FormEntrenador();
    if (modelo == null) {
      throw new Exception(NO_ENCONTRADO);
    } else {
      forma.setTitulo(modelo.getEntrena_nombre());
      forma.setEntrena_nombre(modelo.getEntrena_nombre());
    }
    return forma;
  }
  @Override protected Entrenador leeModelo(HttpServletRequest solicitud)
      throws Exception {
    final Entrenador modelo = new Entrenador();
    modelo.setEntrena_nombre(getTexto(solicitud, ENTRENA_NOMBRE));
    return modelo;
  }
}
