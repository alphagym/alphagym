/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gimnasio.app;

import static com.gimnasio.servlets.UtilServlets.getTexto;
import static com.gimnasio.servlets.UtilServlets.muestraError;
import static com.gimnasio.servlets.UtilServlets.muestraObjetoVacio;
import java.io.IOException;
import java.sql.SQLException;
import javax.ejb.EJB;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author usuario
 */
@MultipartConfig
@WebServlet(name = "CtrlChatMovil",
    urlPatterns = {"/ctrlChatMovil", "/faces/ctrlChatMovil/*"})
public class CtrlChatMovil extends HttpServlet {
  @EJB private CtrlChatWeb ctrlChatWeb;
  @Override public String getServletInfo() {
    return "Reenvía los mensajes recibidos.";
  }
  @Override
  protected void doPost(HttpServletRequest solicitud,
      HttpServletResponse respuesta) throws ServletException, IOException {
    try {
      final String texto = getTexto(solicitud, "usu_clave")
          + ": " + getTexto(solicitud, "mensaje");
      ctrlChatWeb.envia(texto);
      muestraObjetoVacio(respuesta);
    } catch (IOException | SQLException | NamingException e) {
      muestraError(respuesta, getClass().getName(), e);
    }
  }
}
