/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gimnasio.app.entity;

import com.gimnasio.servlets.Entidad;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

/**
 *
 * @author usuario
 */
@Entity
@Table(name = "ADMINISTRADORES")
public class Administradores extends Entidad<Integer> {
  private static final long serialVersionUID = 1L;
  @Id
  @Basic(optional = false)
  @NotNull
  @Column(name = "USU_ID", nullable = false)
  private Integer id;
  @JoinColumn(name = "USU_ID", referencedColumnName = "USU_ID", nullable = false,
      insertable = false, updatable = false)
  @OneToOne(optional = false)
  private Usuarios usuarios;

  @Override
    public Integer getId() {
        return id;
    }

  @Override
    public void setId(Integer id) {
        this.id = id;
    }

    public Usuarios getUsuarios() {
        return usuarios;
    }

    public void setUsuarios(Usuarios usuarios) {
        this.usuarios = usuarios;
    }
 
    
}
