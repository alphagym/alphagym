/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gimnasio.app.entity;

import com.gimnasio.servlets.Entidad;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author usuario
 */
@Entity
@Table(name = "ACTIVIDAD")
@NamedQuery(name = Actividad.TODOS,
    query = "SELECT c FROM Actividad c JOIN c.dia u ORDER BY u.dia_nombre")
public class Actividad extends Entidad<Integer> {
  public static final String TODOS = "Actividad.TODOS";
  private static final long serialVersionUID = 1L; 
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Basic(optional = false)
  //@NotNull (message = "error en el ACTIVIDAD_ID")
  @Column(name = "ACTIVIDAD_ID", nullable = false)
  private Integer id;
  @Basic(optional = false)
  @NotNull(message = "Falta el nombre de la actividad.")
  @Size(min = 1, max = 255, message
      = "El nombre debe tener entre 1 y 255 caracteres.")
  @Column(name = "ACTIVIDAD_NOMBRE", nullable = false, length = 255)
  private String actividad_nombre;
 @Basic(optional = false)
  @NotNull(message = "Falta la descripcion.")
  @Size(min = 1, max = 255, message
      = "la descripcion debe tener entre 1 y 255 caracteres.")
  @Column(name = "ACTIVIDAD_DESC", nullable = false, length = 255)
  private String actividad_desc;
  @JoinColumn(name = "ID_DIA", referencedColumnName = "ID_DIA", nullable = false)
  @OneToOne(optional = false, fetch = FetchType.EAGER)
  private Dia dia;

  @Override
    public Integer getId() {
        return id;
    }

  @Override
    public void setId(Integer id) {
        this.id = id;
    }

    public String getActividad_nombre() {
        return actividad_nombre;
    }

    public void setActividad_nombre(String actividad_nombre) {
        this.actividad_nombre = actividad_nombre;
    }

    public String getActividad_desc() {
        return actividad_desc;
    }

    public void setActividad_desc(String actividad_desc) {
        this.actividad_desc = actividad_desc;
    }

    public Dia getDia() {
        return dia;
    }

    public void setDia(Dia dia) {
        this.dia = dia;
    }
    
}
  
  
  