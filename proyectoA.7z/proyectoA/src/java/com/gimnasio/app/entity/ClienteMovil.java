/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gimnasio.app.entity;

import com.gimnasio.servlets.Entidad;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
/**
 *
 * @author gilberto
 */
@Entity
@Table(name = "CLIENTE_MOVIL")
@NamedQuery(name = ClienteMovil.TODOS, query = "SELECT c FROM ClienteMovil c")
public class ClienteMovil extends Entidad<String> {
  public static final String TODOS = "ClienteMovil.TODOS";
  private static final long serialVersionUID = 1L;
  @Id
  @Basic(optional = false)
  @NotNull
  @Size(min = 1, max = 255)
  @Column(name = "ID_CM", nullable = false, length = 255)
  private String id;
  @Override public String getId() {
    return id;
  }
  @Override public void setId(String id) {
    this.id = id;
  }
}
