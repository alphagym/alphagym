/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gimnasio.app.entity;

import com.gimnasio.servlets.Entidad;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author gilberto
 */
@Entity
@Table(name = "CLIENTES")
@NamedQuery(name = Clientes.TODOS,
    query = "SELECT c FROM Clientes c JOIN c.usuarios u ORDER BY u.clave")
public class Clientes extends Entidad<Integer> {
  public static final String TODOS = "Clientes.TODOS";
  private static final long serialVersionUID = 1L;
  @Id
  @Basic(optional = false)
  @NotNull
  @Column(name = "USU_ID", nullable = false)
  private Integer id;
  @NotNull(message = "Falta el nacimiento.")
  @Column(name = "CLI_NACIMIENTO")
  @Temporal(TemporalType.TIMESTAMP)
  private Date nacimiento;
  @Basic(optional = false)
  @NotNull(message = "Falta el correo.")
  @Size(min = 1, max = 255, message
      = "El nombre debe tener entre 1 y 255 caracteres.")
  @Column(name = "CLI_CORREO", nullable = false, length = 255)
  private String cli_correo;
  @JoinColumn(name = "USU_ID", referencedColumnName = "USU_ID", nullable = false,
      insertable = false, updatable = false)
  @OneToOne(optional = false, fetch = FetchType.EAGER)
  private Usuarios usuarios;

  @Override
    public Integer getId() {
        return id;
    }

  @Override
    public void setId(Integer id) {
        this.id = id;
    }
      public Date getNacimiento() {
        return nacimiento;
    }

    public void setNacimiento(Date nacimiento) {
        this.nacimiento = nacimiento;
    }

    public String getCli_correo() {
        return cli_correo;
    }

    public void setCli_correo(String cli_correo) {
        this.cli_correo = cli_correo;
    }

    public Usuarios getUsuarios() {
        return usuarios;
    }

    public void setUsuarios(Usuarios usuarios) {
        this.usuarios = usuarios;
    }


}