/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gimnasio.app.entity;

import com.gimnasio.servlets.Entidad;
import java.io.InputStream;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author usuario
 */
@Entity
@Table(name = "ARCHIVOS")
public class Archivo extends Entidad<Integer> {
  private static final long serialVersionUID = 1L;
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Basic(optional = false)
  @Column(name = "ARCH_ID", nullable = false)
  private Integer id;
  @Transient
  private InputStream bytes;
  @Override public Integer getId() {
    return id;
  }
  @Override public void setId(Integer id) {
    this.id = id;
  }
  public InputStream getBytes() {
    return bytes;
  }
  public void setBytes(InputStream bytes) {
    this.bytes = bytes;
  }
}
