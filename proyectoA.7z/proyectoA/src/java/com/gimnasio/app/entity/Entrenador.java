/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gimnasio.app.entity;

import com.gimnasio.servlets.Entidad;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author jesus_000
 */
@Entity
@Table(name = "ENTRENADOR",
    uniqueConstraints = {@UniqueConstraint(columnNames = {"ENTRENA_NOMBRE"})})
@NamedQueries({@NamedQuery(name = Entrenador.TODOS,
      query = "SELECT p FROM Entrenador p ORDER BY p.entrena_nombre"),
  @NamedQuery(name = Entrenador.BUSCA_IDS,
      query = "SELECT p FROM Entrenador p WHERE p.id IN :ids")})
public class Entrenador extends Entidad<Integer> {
  public static final String TODOS = "Entrenador.TODOS";
  public static final String BUSCA_IDS = "Entrenador.BUSCA_IDS";
  private static final long serialVersionUID = 1L;
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Basic(optional = false)
  @Column(name = "ENTRENA_ID", nullable = false)
  private Integer id;
  @Basic(optional = false)
  @NotNull(message = "Falta el nombre.")
  @Size(min = 1, max = 255, message
      = "El nombre debe tener entre 1 y 255 caracteres.")
  @Column(name = "ENTRENA_NOMBRE", nullable = false, length = 255)
  private String entrena_nombre;
  @Override public Integer getId() {
    return id;
  }
  @Override public void setId(Integer id) {
    this.id = id;
  }
  public String getEntrena_nombre() {
    return entrena_nombre;
  }
  public void setEntrena_nombre(String entrena_nombre) {
    this.entrena_nombre = entrena_nombre;
  }
}
