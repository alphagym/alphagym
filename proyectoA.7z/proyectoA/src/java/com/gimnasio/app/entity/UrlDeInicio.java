/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gimnasio.app.entity;

public class UrlDeInicio {
  public String getUrl() {
    return url;
  }
  public void setUrl(String url) {
    this.url = url;
  }
  private String url;
}

