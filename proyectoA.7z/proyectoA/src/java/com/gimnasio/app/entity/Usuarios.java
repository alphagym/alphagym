/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gimnasio.app.entity;

import com.gimnasio.servlets.Entidad;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
/**
 *
 * @author usuario
 */
@Entity
@Table(name = "USUARIOS", uniqueConstraints
    = {@UniqueConstraint(columnNames = {"USU_CLAVE"}),
      @UniqueConstraint(columnNames = {"USU_AVATAR"})})
@NamedQueries({@NamedQuery(name = Usuarios.TODOS,
      query = "SELECT u FROM Usuarios u JOIN u.avatar a ORDER BY u.clave"),
  @NamedQuery(name = Usuarios.BUSCA_CLAVE,
      query = "SELECT u FROM Usuarios u WHERE u.clave = :clave")})
public class Usuarios extends Entidad<Integer> {
  public static final String TODOS = "Usuarios.TODOS";
  public static final String BUSCA_CLAVE = "Usuarios.BUSCA_CLAVE";
  private static final long serialVersionUID = 1L;
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Basic(optional = false)
  @Column(name = "USU_ID", nullable = false)
  private Integer id;
  @Basic(optional = false)
  @NotNull
  @Size(min = 1, max = 16)
  @Column(name = "USU_CLAVE", nullable = false, length = 16)
  private String clave;
  @Basic(optional = false)
  @NotNull
  @Size(min = 1, max = 100)
  @Column(name = "USU_CONTRA", nullable = false, length = 100)
  private String contra;
  @Basic(optional = false)
  @NotNull
  @Size(min = 1, max = 255)
  @Column(name = "USU_NOMBRE", nullable = false, length = 255)
  private String nombre;
  @NotNull
  @JoinColumn(name = "USU_AVATAR", referencedColumnName = "ARCH_ID",
      nullable = false)
  @OneToOne(optional = false, orphanRemoval = true, fetch = FetchType.EAGER,
      cascade = CascadeType.REMOVE)
  private Archivo avatar;
  @Override public Integer getId() {
    return id;
  }
  @Override public void setId(Integer usuId) {
    this.id = usuId;
  }
  public String getClave() {
    return clave;
  }
  public void setClave(String clave) {
    this.clave = clave;
  }
  public String getContra() {
    return contra;
  }
  public void setContra(String contra) {
    this.contra = contra;
  }
  public String getNombre() {
    return nombre;
  }
  public void setNombre(String nombre) {
    this.nombre = nombre;
  }
  public Archivo getAvatar() {
    return avatar;
  }
  public void setAvatar(Archivo avatar) {
    this.avatar = avatar;
  }
}
