/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gimnasio.app.entity;

import com.gimnasio.servlets.Entidad;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author usuario
 */
@Entity
@Table(name = "DIA",
    uniqueConstraints = {@UniqueConstraint(columnNames = {"DIA_NOMBRE"})})
@NamedQueries({@NamedQuery(name = Dia.TODOS,
      query = "SELECT p FROM Dia p ORDER BY p.dia_nombre"),
  @NamedQuery(name = Dia.BUSCA_IDS,
      query = "SELECT p FROM Dia p WHERE p.id IN :ids")})
public class Dia extends Entidad<Integer> {
  public static final String TODOS = "Dia.TODOS";
  public static final String BUSCA_IDS = "Dia.BUSCA_IDS";
  private static final long serialVersionUID = 1L;
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Basic(optional = false)
  @Column(name = "ID_DIA", nullable = false)
  private Integer id;
  
  @Basic(optional = false)
  @NotNull(message = "Falta el día.")
  @Size(min = 1, max = 255, message
      = "El nombre debe tener entre 1 y 255 caracteres.")
  @Column(name = "DIA_NOMBRE", nullable = false, length = 255)
  private String dia_nombre;
  
  @Override public Integer getId() {
    return id;
  }
  @Override public void setId(Integer id) {
    this.id = id;
  }

    public String getDia_nombre() {
        return dia_nombre;
    }

    public void setDia_nombre(String dia_nombre) {
        this.dia_nombre = dia_nombre;
    }
  
}
