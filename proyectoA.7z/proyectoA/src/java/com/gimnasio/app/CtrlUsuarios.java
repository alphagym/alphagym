/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gimnasio.app;

import static com.gimnasio.app.Constantes.ARCH_BYTES;
import static com.gimnasio.app.Constantes.FALTA_LA_IMAGEN;
import static com.gimnasio.app.Constantes.LAS_CONTRASENAS_NO_COINCIDEN;
import static com.gimnasio.app.Constantes.NO_ENCONTRADO;
import static com.gimnasio.app.Constantes.URL_ARCHIVO;
import static com.gimnasio.app.Constantes.USU_CLAVE;
import static com.gimnasio.app.Constantes.USU_CONTRA;
import static com.gimnasio.app.Constantes.USU_CONTRA2;
import static com.gimnasio.app.Constantes.USU_NOMBRE;
import com.gimnasio.app.entity.Archivo;
import com.gimnasio.app.entity.Usuarios;
import com.gimnasio.app.info.InfoUsuarios;
import com.gimnasio.app.view_model.FormUsuarios;
import com.gimnasio.comun.Lee;
import com.gimnasio.comun.LeeInteger;
import com.gimnasio.servlets.ServletAbc;
import static com.gimnasio.servlets.UtilServlets.getArchivo;
import static com.gimnasio.servlets.UtilServlets.getTexto;
import com.gimnasio.view_model.FormListado;
import java.io.InputStream;
import java.util.Map;
import java.util.Objects;
import javax.ejb.EJB;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
/**
 *
 * @author usuario
 */
@MultipartConfig
@WebServlet(name = "CtrlUsuarios",
    urlPatterns = {"/ctrlUsuarios/*", "/faces/ctrlUsuarios/*"})
public class CtrlUsuarios extends ServletAbc<Usuarios, Integer> {
  @EJB private InfoUsuarios infoUsuarios;
  @Override protected Lee<Integer> getLeeId() {
    return new LeeInteger();
  }
  @Override protected InfoUsuarios getInfo() {
    return infoUsuarios;
  }
  @Override public String getServletInfo() {
    return "Administra el catálogo de usuarios.";
  }
  @Override protected FormListado list(Map<String, String[]> parámetros) {
    final FormListado forma = new FormListado();
    forma.setListado(infoUsuarios.selectElementosDeLista());
    return forma;
  }
  @Override protected FormUsuarios get(Integer id,
      Map<String, String[]> parámetros) throws Exception {
    final Usuarios modelo = infoUsuarios.get(id);
    final FormUsuarios forma = new FormUsuarios();
    if (modelo == null) {
      throw new Exception(NO_ENCONTRADO);
    } else {
      forma.setTitulo(modelo.getClave());
      forma.setImagen(URL_ARCHIVO + modelo.getAvatar().getId());
      forma.setUsu_clave(modelo.getClave());
      forma.setUsu_contra("");
      forma.setUsu_contra2("");
      forma.setUsu_nombre(modelo.getNombre());
    }
    return forma;
  }
  @Override protected Integer insert(Usuarios modelo) throws Exception {
    if (modelo.getAvatar() == null) {
      throw new Exception(FALTA_LA_IMAGEN);
    }
    return super.insert(modelo);
  }
  @Override
  protected Usuarios leeModelo(HttpServletRequest solicitud) throws
      Exception {
    final Usuarios modelo = new Usuarios();
    final String usu_contra = getTexto(solicitud, USU_CONTRA);
    final String usu_contra2 = getTexto(solicitud, USU_CONTRA2);
    if (!Objects.equals(usu_contra, usu_contra2)) {
      throw new Exception(LAS_CONTRASENAS_NO_COINCIDEN);
    } else {
      modelo.setContra(usu_contra);
      modelo.setClave(getTexto(solicitud, USU_CLAVE));
      modelo.setNombre(getTexto(solicitud, USU_NOMBRE));
      final InputStream bytes = getArchivo(solicitud, ARCH_BYTES);
      if (bytes != null) {
        final Archivo archivo = new Archivo();
        archivo.setBytes(bytes);
        modelo.setAvatar(archivo);
      }
    }
    return modelo;
  }
}

