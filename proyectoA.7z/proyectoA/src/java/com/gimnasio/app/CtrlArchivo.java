/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gimnasio.app;

import static com.gimnasio.app.Constantes.NO_ENCONTRADO;
import com.gimnasio.app.info.InfoArchivo;
import static com.gimnasio.servlets.UtilServlets.muestraError;
import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author usuario
 */
@WebServlet(name = "CtrlArchivo",
    urlPatterns = {"/ctrlArchivo/*", "/faces/ctrlArchivo/*"})
public class CtrlArchivo extends HttpServlet {
  @EJB private InfoArchivo infoArchivo;
  @Override public String getServletInfo() {
    return "Descarga un archivo.";
  }
  @Override protected void doGet(HttpServletRequest solicitud,
      HttpServletResponse respuesta) throws ServletException, IOException {
    final String pathInfo = solicitud.getPathInfo();
    try {
      if (pathInfo == null) {
        throw new Exception(NO_ENCONTRADO);
      } else {
        final String id = pathInfo.substring(1);
        infoArchivo.muestraBytes(new Integer(id), respuesta);
      }
    } catch (Exception e) {
      muestraError(respuesta, getClass().getName(), e);
    }
  }
}
