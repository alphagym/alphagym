/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gimnasio.app.view_model;

import com.gimnasio.view_model.FormDetalle;
import com.gimnasio.view_model.Opcion;
import java.util.List;

public class FormActividad extends FormDetalle {
  private List<Opcion> id_dia;
  private String actividad_nombre;
  private String actividad_desc;

    public List<Opcion> getId_dia() {
        return id_dia;
    }

    public void setId_dia(List<Opcion> id_dia) {
        this.id_dia = id_dia;
    }

    public String getActividad_nombre() {
        return actividad_nombre;
    }

    public void setActividad_nombre(String actividad_nombre) {
        this.actividad_nombre = actividad_nombre;
    }

    public String getActividad_desc() {
        return actividad_desc;
    }

    public void setActividad_desc(String actividad_desc) {
        this.actividad_desc = actividad_desc;
    }
  
}
