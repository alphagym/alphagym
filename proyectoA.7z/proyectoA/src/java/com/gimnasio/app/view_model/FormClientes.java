/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gimnasio.app.view_model;

import com.gimnasio.view_model.FormDetalle;
import com.gimnasio.view_model.Opcion;
import java.util.List;
/**
 *
 * @author usuario
 */
public class FormClientes extends FormDetalle {
  private List<Opcion> usu_id;
  private String cli_nacimiento;
  private String cli_correo;

    public List<Opcion> getUsu_id() {
        return usu_id;
    }

    public void setUsu_id(List<Opcion> usu_id) {
        this.usu_id = usu_id;
    }

    public String getCli_nacimiento() {
        return cli_nacimiento;
    }

    public void setCli_nacimiento(String cli_nacimiento) {
        this.cli_nacimiento = cli_nacimiento;
    }

    public String getCli_correo() {
        return cli_correo;
    }

    public void setCli_correo(String cli_correo) {
        this.cli_correo = cli_correo;
    }

}
