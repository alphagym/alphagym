/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gimnasio.app.view_model;

import java.util.Set;

/**
 *
 * @author usuario
 */
public class FormSesion {
  private String usu_clave;
  private String usu_nombre;
  private String usu_avatar;
  private Set<String> roles;
  public String getUsu_clave() {
    return usu_clave;
  }
  public void setUsu_clave(String usu_clave) {
    this.usu_clave = usu_clave;
  }
  public String getUsu_nombre() {
    return usu_nombre;
  }
  public void setUsu_nombre(String usu_nombre) {
    this.usu_nombre = usu_nombre;
  }
  public String getUsu_avatar() {
    return usu_avatar;
  }
  public void setUsu_avatar(String usu_avatar) {
    this.usu_avatar = usu_avatar;
  }
  public Set<String> getRoles() {
    return roles;
  }
  public void setRoles(Set<String> roles) {
    this.roles = roles;
  }
}

