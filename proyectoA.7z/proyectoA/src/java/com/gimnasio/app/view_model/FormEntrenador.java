/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gimnasio.app.view_model;

import com.gimnasio.view_model.FormDetalle;

/**
 *
 * @author jesus_000
 */
public class FormEntrenador extends FormDetalle {
  private String entrena_nombre;
  public String getEntrena_nombre() {
    return entrena_nombre;
  }
  public void setEntrena_nombre(String entrena_nombre) {
    this.entrena_nombre = entrena_nombre;
  }
}
