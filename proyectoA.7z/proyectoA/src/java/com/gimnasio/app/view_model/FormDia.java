/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gimnasio.app.view_model;

import com.gimnasio.view_model.FormDetalle;

/**
 *
 * @author usuario
 */
public class FormDia extends FormDetalle {
  private String dia_nombre;
  
  public String getDia_nombre() {
    return dia_nombre;
  }
  public void setDia_nombre(String dia_nombre) {
    this.dia_nombre = dia_nombre;
  }
}

