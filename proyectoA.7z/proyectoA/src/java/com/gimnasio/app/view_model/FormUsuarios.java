/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gimnasio.app.view_model;

import com.gimnasio.view_model.FormDetalle;

/**
 *
 * @author usuario
 */
public class FormUsuarios extends FormDetalle {
  private String usu_clave;
  private String imagen;
  private String usu_contra;
  private String usu_contra2;
  private String usu_nombre;
  public String getImagen() {
    return imagen;
  }
  public void setImagen(String imagen) {
    this.imagen = imagen;
  }
  public String getUsu_clave() {
    return usu_clave;
  }
  public void setUsu_clave(String usu_clave) {
    this.usu_clave = usu_clave;
  }
  public String getUsu_contra() {
    return usu_contra;
  }
  public void setUsu_contra(String usu_contra) {
    this.usu_contra = usu_contra;
  }
  public String getUsu_contra2() {
    return usu_contra2;
  }
  public void setUsu_contra2(String usu_contra2) {
    this.usu_contra2 = usu_contra2;
  }
  public String getUsu_nombre() {
    return usu_nombre;
  }
  public void setUsu_nombre(String usu_nombre) {
    this.usu_nombre = usu_nombre;
  }
}
