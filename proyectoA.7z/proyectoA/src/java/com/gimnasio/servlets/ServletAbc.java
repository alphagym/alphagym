/* Copyright 2016 Gilberto Pacheco Gallegos Licensed under the Apache License,
 * Version 2.0 (the "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *   http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License. */
package com.gimnasio.servlets;

import java.io.IOException;
import java.util.Map;
import java.util.Objects;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.gimnasio.comun.Lee;
import static com.gimnasio.servlets.UtilServlets.muestraError;
import static com.gimnasio.servlets.UtilServlets.muestraObjeto;
import static com.gimnasio.servlets.UtilServlets.muestraObjetoVacio;
import com.gimnasio.view_model.ObjetoId;

public abstract class ServletAbc<E extends Entidad<I>, I> extends HttpServlet {
  @Override public String getServletInfo() {
    return "Servicio REST que realiza el mantenimiento de una entidad.";
  }
  protected abstract Lee<I> getLeeId();
  protected abstract InfoBase<E, I> getInfo();
  protected abstract E leeModelo(HttpServletRequest solicitud) throws Exception;
  @Override protected void doGet(HttpServletRequest solicitud,
      HttpServletResponse respuesta) throws ServletException, IOException {
    try {
      final String pathInfo = solicitud.getPathInfo();
      final Object objeto;
      if (pathInfo == null) {
        objeto = list(solicitud.getParameterMap());
      } else {
        final String id = pathInfo.substring(1);
        objeto = get(getLeeId().lee(id), solicitud.getParameterMap());
      }
      muestraObjeto(respuesta, objeto);
    } catch (Exception e) {
      muestraError(respuesta, getClass().getName(), e);
    }
  }
  @Override protected void doPost(HttpServletRequest solicitud,
      HttpServletResponse respuesta) throws ServletException, IOException {
    try {
      final String pathInfo = solicitud.getPathInfo();
      final E modelo = leeModelo(solicitud);
      if (pathInfo == null) {
        final I object = insert(modelo);
        muestraObjeto(respuesta, new ObjetoId(Objects.toString(object, null)));
      } else {
        final String id = pathInfo.substring(1);
        update(getLeeId().lee(id), modelo);
        muestraObjetoVacio(respuesta);
      }
    } catch (Exception e) {
      muestraError(respuesta, getClass().getName(), e);
    }
  }
  @Override protected void doDelete(HttpServletRequest solicitud,
      HttpServletResponse respuesta) throws ServletException, IOException {
    final String pathInfo = solicitud.getPathInfo();
    try {
      if (pathInfo != null) {
        final String id = pathInfo.substring(1);
        delete(getLeeId().lee(id));
      }
      muestraObjetoVacio(respuesta);
    } catch (Exception e) {
      muestraError(respuesta, getClass().getName(), e);
    }
  }
  protected Object list(Map<String, String[]> parámetros) throws
      Exception {
    throw new UnsupportedOperationException("List no permitido.");
  }
  protected Object get(I id, Map<String, String[]> parámetros) throws
      Exception {
    throw new UnsupportedOperationException("Get no permitido.");
  }
  protected I insert(E modelo) throws Exception {
    getInfo().insert(modelo);
    return modelo.getId();
  }
  protected void update(I id, E modelo) throws Exception {
    modelo.setId(id);
    getInfo().update(modelo);
  }
  protected void delete(I id) throws Exception {
    getInfo().delete(id);
  }
}
