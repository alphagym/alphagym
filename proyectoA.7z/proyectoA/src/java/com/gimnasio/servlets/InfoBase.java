/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gimnasio.servlets;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.validation.Validator;

/**
 *
 * @author gilberto
 * @param <T>
 * @param <I>
 */
public abstract class InfoBase<T, I> {
  @Resource
  private Validator validator;
  private final Class<T> entityClass;
  public InfoBase(Class<T> entityClass) {
    this.entityClass = entityClass;
  }
  protected abstract EntityManager getEntityManager();
  public T get(I id) {
    return id == null ? null : getEntityManager().find(entityClass, id);
  }
  public void insert(T entity) throws Exception {
    getEntityManager().persist(entity);
  }
  public T update(T entity) throws Exception {
    return getEntityManager().merge(entity);
  }
  public void delete(I id) throws Exception {
    final T entity = getEntityManager().find(entityClass, id);
    if (entity != null) {
      getEntityManager().remove(entity);
    }
  }
}
