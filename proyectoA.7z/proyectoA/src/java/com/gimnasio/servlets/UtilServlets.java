/* Copyright 2016 Gilberto Pacheco Gallegos Licensed under the Apache License,
 * Version 2.0 (the "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *   http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License. */
package com.gimnasio.servlets;

import com.fasterxml.jackson.jr.ob.JSON;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.json.JsonObjectBuilder;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import javax.validation.ConstraintViolationException;
import javax.ws.rs.core.MediaType;
import static com.gimnasio.comun.Strings.isNullOrEmpty;
import com.gimnasio.comun.UtilComun;
import static com.gimnasio.comun.UtilComun.getMensaje;
import static com.gimnasio.comun.UtilComun.parse;
import com.gimnasio.view_model.Opcion;

public class UtilServlets {
  public static final String UTF_8 = StandardCharsets.UTF_8.name();
  public static void addJson(JsonObjectBuilder json, String nombre, String valor) {
    if (valor != null) {
      json.add(nombre, valor);
    }
  }
  public static void muestraObjetoVacio(HttpServletResponse respuesta) throws
      IOException {
    respuesta.setContentType(MediaType.APPLICATION_JSON);
    respuesta.setCharacterEncoding(UTF_8);
    muestraSinCache(respuesta);
    respuesta.getWriter().print("{}");
  }
  public static void muestraObjeto(HttpServletResponse respuesta,
      final Object objeto) throws IOException {
    respuesta.setContentType(MediaType.APPLICATION_JSON);
    respuesta.setCharacterEncoding(UTF_8);
    muestraSinCache(respuesta);
    JSON.std.write(objeto, respuesta.getWriter());
  }
  public static void muestraError(HttpServletResponse respuesta, String etiqueta,
      Exception e) throws IOException {
    Logger.getLogger(etiqueta).log(Level.SEVERE, null, e);
    respuesta.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
    respuesta.setContentType(MediaType.TEXT_PLAIN);
    respuesta.setCharacterEncoding(UTF_8);
    // Detecta las violaciones de restricciones.
    Throwable cause = e.getCause();
    while (cause != null && !(cause instanceof ConstraintViolationException)) {
      cause = cause.getCause();
    }
    if (cause instanceof ConstraintViolationException) {
      ConstraintViolationException ex = (ConstraintViolationException) cause;
      respuesta.getWriter().print(
          ex.getConstraintViolations().iterator().next().getMessage());
    } else {
      respuesta.getWriter().print(getMensaje(e));
    }
  }
  public static void muestraSinCache(HttpServletResponse respuesta) {
    respuesta.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
    respuesta.setHeader("Pragma", "no-cache");
    respuesta.setIntHeader("Expires", 0);
  }
  public static String getTexto(HttpServletRequest solicitud, String parámetro)
      throws IOException, ServletException {
    final Part part = solicitud.getPart(parámetro);
    return part == null ? null : UtilComun.getTexto(part.getInputStream(),
        StandardCharsets.UTF_8.name());
  }
  public static Integer getInteger(HttpServletRequest solicitud,
      String parámetro) throws Exception {
    final String texto = getTexto(solicitud, parámetro);
    return isNullOrEmpty(texto) ? null : Integer.parseInt(texto);
  }
  public static BigDecimal getBigDecimal(HttpServletRequest solicitud,
      String parámetro, DecimalFormat fmt, String mensajeDeError)
      throws Exception {
    fmt.setParseBigDecimal(true);
    return (BigDecimal) parse(fmt, getTexto(solicitud, parámetro),
        mensajeDeError);
  }
  public static Date getFecha(HttpServletRequest solicitud,
      String parámetro, DateFormat fmt, String mensajeDeError)
      throws Exception {
    return (Date) parse(fmt, getTexto(solicitud, parámetro),
        mensajeDeError);
  }
  public static InputStream getArchivo(HttpServletRequest solicitud,
      String parámetro) throws IOException, ServletException {
    final Part part = solicitud.getPart(parámetro);
    if (part == null) {
      return null;
    } else {
      final InputStream is = part.getSize() == 0 ? null : part.getInputStream();
      return is == null ? null : new BufferedInputStream(is);
    }
  }
  public static List<Integer> getEnteros(HttpServletRequest request,
      String parámetro) throws IOException, ServletException {
    final List<Integer> resultado = new ArrayList<>();
    for (Part part : request.getParts()) {
      if (parámetro.equals(part.getName())) {
        resultado.
            add(new Integer(UtilComun.getTexto(part.getInputStream(), UTF_8)));
      }
    }
    return resultado;
  }
  /** Encripta datos con el algoritmo SHA-256.
   * @param texto el contenido que se desea encriptar
   * @return el texto encriptado
   * @throws NoSuchAlgorithmException si la implementación no soporta el
   * algoritmo SHA-256.
   * @throws UnsupportedEncodingException si la implementación no soporta UTF-8.
   */
  public static String encripta(final String texto) throws
      NoSuchAlgorithmException, UnsupportedEncodingException {
    final MessageDigest md = MessageDigest.getInstance("SHA-256");
    final byte[] bytes = md.digest(texto.getBytes(UTF_8));
    return Base64.getEncoder().encodeToString(bytes);
  }
  public static List<Opcion> configuraSeleccionaUno(String valorSinSelección,
      String mensajeSinSelección, String selección, List<Opcion> opciones) {
    if (isNullOrEmpty(selección)) {
      opciones.add(0, new Opcion(true, valorSinSelección, mensajeSinSelección));
      opciones.stream().forEach(o -> o.setSeleccionada(false));
    } else {
      opciones.add(0, new Opcion(false, valorSinSelección, mensajeSinSelección));
      opciones.stream().forEach(o
          -> o.setSeleccionada(Objects.equals(selección, o.getValor())));
    }
    return opciones;
  }
  public static List<Opcion> configuraSeleccionaMuchos(
      Collection<String> selección, List<Opcion> opciones) {
    if (selección == null || selección.isEmpty()) {
      opciones.stream().forEach(o -> o.setSeleccionada(false));
    } else {
      opciones.stream().forEach(o
          -> o.setSeleccionada(selección.contains(o.getValor())));
    }
    return opciones;
  }
}
